#!/usr/bin/env python3
"""
knot_client.py — 调用 knot 智能体 AG-UI 端点（SSE 流式），返回最终文本回复。

用途：让 WorkBuddy automation / 灯塔机定时任务在外部调用 knot，
驱动它执行"读 active_rules + 读日报 + 5维度质检 + qc_submit 存档"等任务，
实现"每天自动质检"（触发在 automation，判断在 knot）。

鉴权：
  x-knot-api-token: <个人或团队 token>
  x-knot-api-user:  <企微英文名>（团队 token 必填；个人 token 也建议填）

用法：
  python knot_client.py --message "请对今天的日报做质检并存档" [--conv <id>] [--raw]
环境变量（优先级高于默认）：
  KNOT_AGENT_ID / KNOT_API_TOKEN / KNOT_API_USER / KNOT_BASE
"""
import os
import sys
import json
import argparse
import urllib.request
import urllib.error
import ssl

KNOT_BASE = os.environ.get("KNOT_BASE", "https://knot.woa.com")
AGENT_ID = os.environ.get("KNOT_AGENT_ID", "e3cfb1022d274d7babaf185cbc7cf4cc")
API_TOKEN = os.environ.get("KNOT_API_TOKEN", "")
API_USER = os.environ.get("KNOT_API_USER", "tianyumamao")
_ctx = ssl.create_default_context()


def call_knot(message, conversation_id="", timeout=300):
    """
    调 knot AG-UI 端点，流式读取，返回 (final_text, conversation_id, events_summary)。
    """
    url = f"{KNOT_BASE}/apigw/api/v1/agents/agui/{AGENT_ID}"
    body = json.dumps({"input": {
        "message": message,
        "conversation_id": conversation_id,
        "stream": True,
    }}).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "x-knot-api-token": API_TOKEN,
        "x-knot-api-user": API_USER,
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")

    text_parts = []
    conv_id = conversation_id
    tool_calls = []
    final_run = False
    with urllib.request.urlopen(req, context=_ctx, timeout=timeout) as resp:
        for raw in resp:
            line = raw.decode("utf-8", errors="ignore").strip()
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            try:
                ev = json.loads(payload)
            except Exception:
                continue
            t = ev.get("type")
            re_ = ev.get("rawEvent", {}) or {}
            if not conv_id:
                conv_id = re_.get("conversation_id") or ev.get("threadId") or ""
            # 正式回复文本（排除 THINKING_*）
            if t == "TEXT_MESSAGE_CONTENT":
                for k in ("delta", "content", "text"):
                    v = ev.get(k)
                    if isinstance(v, str) and v:
                        text_parts.append(v)
            elif t == "TOOL_CALL_START":
                nm = re_.get("ch_name") or re_.get("name") or ev.get("toolCallName")
                if nm:
                    tool_calls.append(nm)
            elif t == "RUN_FINISHED":
                final_run = True
    return {
        "text": "".join(text_parts).strip(),
        "conversation_id": conv_id,
        "tool_calls": tool_calls,
        "finished": final_run,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--message", required=True)
    ap.add_argument("--conv", default="")
    ap.add_argument("--raw", action="store_true", help="输出完整 JSON 结果")
    ap.add_argument("--timeout", type=int, default=300)
    args = ap.parse_args()
    if not API_TOKEN:
        print("ERR: 未设置 KNOT_API_TOKEN 环境变量", file=sys.stderr)
        return 2
    try:
        r = call_knot(args.message, args.conv, args.timeout)
    except urllib.error.HTTPError as e:
        print(f"ERR HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:300]}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"ERR {type(e).__name__}: {e}", file=sys.stderr)
        return 1
    if args.raw:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print(r["text"])
        if r["tool_calls"]:
            print(f"\n[调用工具: {', '.join(r['tool_calls'])}]", file=sys.stderr)
        print(f"[conversation_id: {r['conversation_id']}]", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
