#!/usr/bin/env python3
"""
daily_qc_runner.py — 每日自动日报质检（灯塔机 cron 调用）

链路：cron 定时 → 本脚本 → 调 knot(AG-UI) 让它执行完整质检并 daily_qc_submit 存档
     → 回读质检库拿结构化结论 → 按策略推送企微（可选，单人群 webhook）

为什么触发在这里、判断在 knot：
  knot 不能自唤醒，所以定时触发只能由外部（cron）做；但质检"判断"由 knot
  （受黄金集校准 + active_rules 用户批准规则约束的大脑）做，比脚本写死规则更准。

环境变量：
  KNOT_API_TOKEN   (必填) knot 个人/团队 token
  KNOT_API_USER    (必填) 企微英文名，默认 tianyumamao
  KNOT_AGENT_ID    knot 智能体 id（默认已内置）
  BUTLER_API_BASE  butler_api 基址（默认 http://127.0.0.1:8901，灯塔机本机）
  BUTLER_API_AUTH  basic auth "user:pass"（默认 butler:heylishio）
  QC_WECOM_WEBHOOK 企微 webhook（留空=不推送，只存档）；建议填"只有你一人的群"webhook
  QC_PUSH_POLICY   always | fail_only | never（默认 fail_only：只有 verdict=fail 才推）

退出码：0 成功（含 pass/warn/fail），非0 表示链路异常（knot 调用失败等）
"""
import os
import sys
import json
import base64
import urllib.request
import urllib.error
import ssl
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from knot_client import call_knot  # 同目录
except Exception:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from knot_client import call_knot

_ctx = ssl.create_default_context()
BUTLER_BASE = os.environ.get("BUTLER_API_BASE", "http://127.0.0.1:8901")
BUTLER_AUTH = os.environ.get("BUTLER_API_AUTH", "butler:heylishio")
WECOM_WEBHOOK = os.environ.get("QC_WECOM_WEBHOOK", "").strip()
PUSH_POLICY = os.environ.get("QC_PUSH_POLICY", "fail_only").lower()

QC_PROMPT = (
    "现在执行每日日报质检任务（automation 定时触发）：\n"
    "1. 先调 active_rules 读取已生效规则；\n"
    "2. 用 daily_get 读取最新一期日报（若当天没有则取最近一期）；\n"
    "3. 对每条新闻按 5 维度质检：板块归属 / P级定级(P0须Direct+已发生) / "
    "合并查重(archive_search查近7天) / 实质进展 / 信源等级；\n"
    "4. 调 daily_qc_submit 把结论存档（date 用日报实际日期，verdict/summary/issues/stats 填全）；\n"
    "5. 最后用一段话给出初步分析判断结论。务必真正调用工具完成存档，不要只口头描述。"
)


def _butler_get(path):
    url = f"{BUTLER_BASE}{path}"
    req = urllib.request.Request(url, headers={"User-Agent": "qc-runner"})
    if BUTLER_AUTH:
        tok = base64.b64encode(BUTLER_AUTH.encode()).decode()
        req.add_header("Authorization", f"Basic {tok}")
    with urllib.request.urlopen(req, context=_ctx, timeout=30) as r:
        return json.loads(r.read().decode("utf-8", errors="ignore"))


def _push_wecom(md):
    if not WECOM_WEBHOOK:
        return {"ok": False, "error": "no_webhook_configured"}
    payload = json.dumps({"msgtype": "markdown", "markdown": {"content": md}},
                         ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(WECOM_WEBHOOK, data=payload,
                                 headers={"Content-Type": "application/json; charset=utf-8"},
                                 method="POST")
    try:
        with urllib.request.urlopen(req, context=_ctx, timeout=15) as r:
            res = json.loads(r.read().decode("utf-8", errors="ignore"))
            return {"ok": res.get("errcode", 0) == 0, "result": res}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def main():
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[{ts}] daily_qc_runner start")
    if not os.environ.get("KNOT_API_TOKEN"):
        print("ERR: KNOT_API_TOKEN 未设置", file=sys.stderr)
        return 2

    # 1) 驱动 knot 执行质检
    try:
        r = call_knot(QC_PROMPT, conversation_id="", timeout=300)
    except Exception as e:
        print(f"ERR knot 调用失败: {type(e).__name__}: {e}", file=sys.stderr)
        return 1
    print(f"  knot 工具调用: {r.get('tool_calls')}")
    print(f"  knot 结论文本(前300): {r.get('text','')[:300]}")

    # 2) 回读最新质检报告拿结构化 verdict
    verdict, date, summary, issues = None, None, "", []
    try:
        lst = _butler_get("/api/daily/qc_list")
        dates = lst.get("dates", [])
        # 取 knot 实际质检那期（最近一期有真实 verdict 的）
        for d in dates:
            rep = _butler_get(f"/api/daily/qc_get?date={d}").get("data", {})
            if rep.get("verdict") and rep.get("qc_by") == "knot":
                verdict, date = rep["verdict"], rep.get("date", d)
                summary, issues = rep.get("summary", ""), rep.get("issues", [])
                break
    except Exception as e:
        print(f"  WARN 回读质检库失败: {e}", file=sys.stderr)

    print(f"  存档结果: date={date} verdict={verdict} issues={len(issues)}")

    # 3) 按策略推送
    should_push = (PUSH_POLICY == "always") or (PUSH_POLICY == "fail_only" and verdict == "fail")
    if should_push and verdict:
        icon = {"pass": "✅", "warn": "⚠️", "fail": "🔴"}.get(verdict, "ℹ️")
        md = (f"# {icon} 日报质检 {date or ''}\n"
              f"**结论：{verdict.upper()}**　问题 {len(issues)} 条\n\n"
              f"{summary[:600]}\n")
        if issues:
            md += "\n**问题清单：**\n"
            for it in issues[:5]:
                md += f"- [{it.get('dimension')}/{it.get('severity')}] {it.get('detail','')[:80]}\n"
        md += "\n_详情可问 knot：今天日报质检结果_"
        res = _push_wecom(md)
        print(f"  企微推送: {res}")
    else:
        print(f"  企微推送: 跳过（policy={PUSH_POLICY}, verdict={verdict}, webhook={'set' if WECOM_WEBHOOK else 'none'}）")

    print(f"[{ts}] daily_qc_runner done")
    return 0


if __name__ == "__main__":
    sys.exit(main())
