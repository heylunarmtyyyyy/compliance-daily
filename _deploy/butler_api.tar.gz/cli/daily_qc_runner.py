#!/usr/bin/env python3
"""
daily_qc_runner.py — 每日自动日报质检（灯塔机 cron 调用）

链路：cron 定时 → 本脚本 → 调 knot(AG-UI) 让它执行完整质检并 daily_qc_submit 存档
     → 回读质检库拿结构化结论 → 按策略推送企微（可选，单人群 webhook）

为什么触发在这里、判断在 knot：
  knot 不能自唤醒，所以定时触发只能由外部（cron）做；但质检"判断"由 knot
  （受黄金集校准 + active_rules 用户批准规则约束的大脑）做，比脚本写死规则更准。

环境变量：
  KNOT_API_TOKEN   (必填) knot 个人/团队 token
  KNOT_API_USER    (必填) 企微英文名，默认 tianyumamao
  KNOT_AGENT_ID    knot 智能体 id（默认已内置）
  BUTLER_API_BASE  butler_api 基址（默认 http://127.0.0.1:8901，灯塔机本机）
  BUTLER_API_AUTH  basic auth "user:pass"（默认 butler:heylishio）
  QC_WECOM_WEBHOOK 企微 webhook（留空=不推送，只存档）；建议填"只有你一人的群"webhook
  QC_PUSH_POLICY   always | fail_only | never（默认 fail_only：只有 verdict=fail 才推）

退出码：0 成功（含 pass/warn/fail），非0 表示链路异常（knot 调用失败等）
"""
import os
import sys
import json
import time
import base64
import urllib.request
import urllib.error
import ssl
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from knot_client import call_knot  # 同目录
except Exception:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from knot_client import call_knot

_ctx = ssl.create_default_context()


def _load_secrets_file():
    """
    从受保护的本地 secrets 文件加载环境变量（KEY=VALUE 行），不覆盖已存在的环境变量。
    路径优先级：QC_SECRETS_FILE 环境变量 > ~/.workbuddy/secrets/knot_qc.env
    用途：让 WorkBuddy automation 触发时无需在 prompt 里写明文 token。
    """
    candidates = []
    if os.environ.get("QC_SECRETS_FILE"):
        candidates.append(os.environ["QC_SECRETS_FILE"])
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    candidates.append(os.path.join(home, ".workbuddy", "secrets", "knot_qc.env"))
    for p in candidates:
        try:
            if not p or not os.path.exists(p):
                continue
            with open(p, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if line.startswith("export "):
                        line = line[7:]
                    if "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    k, v = k.strip(), v.strip().strip('"').strip("'")
                    os.environ.setdefault(k, v)
            print(f"  secrets loaded: {p}")
            break
        except Exception as e:
            print(f"  WARN 读 secrets 失败 {p}: {e}", file=sys.stderr)


_load_secrets_file()

BUTLER_BASE = os.environ.get("BUTLER_API_BASE", "http://127.0.0.1:8901")
BUTLER_AUTH = os.environ.get("BUTLER_API_AUTH", "butler:heylishio")
WECOM_WEBHOOK = os.environ.get("QC_WECOM_WEBHOOK", "").strip()
PUSH_POLICY = os.environ.get("QC_PUSH_POLICY", "fail_only").lower()

QC_PROMPT = (
    "执行日报质检（automation 定时触发，请务必真正调用工具完成，不要只口头描述）：\n"
    "1. 调 active_rules 读已生效规则；\n"
    "2. 调 daily_status 查最新一期日报日期（今天若无则取最近一期），记下该日期 D；\n"
    "3. 调 daily_get 读 D 的日报全文；\n"
    "4. 按 5 维度逐条质检：板块归属 / P级定级(P0须Direct+已发生) / 合并查重 / 实质进展 / 信源等级；\n"
    "5. 调 daily_qc_submit 存档（date=D，verdict/summary/issues/stats 填全）；\n"
    "6. 用一段话给出初步分析判断结论。"
)


def _butler_get(path):
    url = f"{BUTLER_BASE}{path}"
    req = urllib.request.Request(url, headers={"User-Agent": "qc-runner"})
    if BUTLER_AUTH:
        tok = base64.b64encode(BUTLER_AUTH.encode()).decode()
        req.add_header("Authorization", f"Basic {tok}")
    with urllib.request.urlopen(req, context=_ctx, timeout=30) as r:
        return json.loads(r.read().decode("utf-8", errors="ignore"))


def _push_wecom(md):
    if not WECOM_WEBHOOK:
        return {"ok": False, "error": "no_webhook_configured"}
    payload = json.dumps({"msgtype": "markdown", "markdown": {"content": md}},
                         ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(WECOM_WEBHOOK, data=payload,
                                 headers={"Content-Type": "application/json; charset=utf-8"},
                                 method="POST")
    try:
        with urllib.request.urlopen(req, context=_ctx, timeout=15) as r:
            res = json.loads(r.read().decode("utf-8", errors="ignore"))
            return {"ok": res.get("errcode", 0) == 0, "result": res}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _stamp_path():
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    d = os.path.join(home, ".workbuddy", "secrets")
    return os.path.join(d, "qc_done.txt")


def _already_done_today():
    """今天是否已成功完成过质检（幂等：补偿 automation 跑时若已完成则跳过）。"""
    try:
        p = _stamp_path()
        if not os.path.exists(p):
            return False
        stamp = open(p, encoding="utf-8").read().strip()
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        return stamp == today
    except Exception:
        return False


def _mark_done_today():
    try:
        p = _stamp_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(datetime.now(timezone.utc).strftime("%Y-%m-%d"))
    except Exception as e:
        print(f"  WARN 写完成标记失败: {e}", file=sys.stderr)


def main():
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[{ts}] daily_qc_runner start")
    if not os.environ.get("KNOT_API_TOKEN"):
        print("ERR: KNOT_API_TOKEN 未设置", file=sys.stderr)
        return 2

    # 幂等：今天已成功完成过 → 直接跳过（供 12:30 补偿 automation 安全空跑）
    if not os.environ.get("QC_FORCE") and _already_done_today():
        print("  今日质检已完成（标记存在），跳过本次（补偿空跑）")
        print(f"[{ts}] daily_qc_runner done (already completed today)")
        return 0

    # 1) 驱动 knot 执行质检（空响应退避重试：knot 对短时间重复重任务偶发空流）
    r = None
    max_tries = 3
    for attempt in range(1, max_tries + 1):
        try:
            r = call_knot(QC_PROMPT, conversation_id="", timeout=300)
        except Exception as e:
            print(f"  ERR knot 调用失败(第{attempt}次): {type(e).__name__}: {e}", file=sys.stderr)
            r = None
        else:
            # knot 真干活的判据：有工具调用 或 有实质文本
            if r.get("tool_calls") or len(r.get("text", "")) > 20:
                break
            print(f"  WARN knot 第{attempt}次返回空（无工具调用且无文本）", file=sys.stderr)
            r = None
        if attempt < max_tries:
            backoff = 20 * attempt  # 20s, 40s 退避，避开频率保护
            print(f"  退避 {backoff}s 后重试…", file=sys.stderr)
            time.sleep(backoff)
    knot_ok = r is not None and (r.get("tool_calls") or len(r.get("text", "")) > 20)
    if r:
        print(f"  knot 工具调用: {r.get('tool_calls')}")
        print(f"  knot 结论文本(前300): {r.get('text','')[:300]}")

    # 2) 回读最新质检报告拿结构化 verdict（仅取今天新产出的，避免推陈旧结论）
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    verdict, date, summary, issues, qc_at = None, None, "", [], ""
    try:
        lst = _butler_get("/api/daily/qc_list")
        dates = lst.get("dates", [])
        for d in dates:
            rep = _butler_get(f"/api/daily/qc_get?date={d}").get("data", {})
            if rep.get("verdict") and rep.get("qc_by") == "knot":
                verdict, date = rep["verdict"], rep.get("date", d)
                summary, issues = rep.get("summary", ""), rep.get("issues", [])
                qc_at = rep.get("qc_at", "")
                break
    except Exception as e:
        print(f"  WARN 回读质检库失败: {e}", file=sys.stderr)

    # 报告是否为本次新产出（qc_at 是今天）——防止 knot 空跑后把昨天的结论当今天推
    fresh = bool(qc_at and qc_at[:10] == today)
    print(f"  存档结果: date={date} verdict={verdict} issues={len(issues)} qc_at={qc_at} fresh={fresh} knot_ok={knot_ok}")

    # 3) 按策略推送
    if not knot_ok or not fresh:
        # knot 没真质检 / 没有今天的新报告 → 不推陈旧结论，按需推异常提醒
        reason = "knot 多次返回空，未完成质检" if not knot_ok else "今日质检报告未生成（knot 未产出当日结论）"
        print(f"  企微推送: 跳过正常结论（{reason}）")
        if WECOM_WEBHOOK and PUSH_POLICY in ("always", "fail_only"):
            warn_md = (f"# ⚠️ 日报质检未完成\n"
                       f"今日（{today}）自动质检未拿到有效结论：{reason}。\n\n"
                       f"最近一份存档：{date or '无'}（verdict={verdict or '无'}）。\n"
                       f"_可手动问 knot：帮我质检最新日报_")
            print(f"  企微推送(异常提醒): {_push_wecom(warn_md)}")
        print(f"[{ts}] daily_qc_runner done (no fresh result)")
        return 0

    # 走到这里说明 knot 真质检了且产出了今天的新报告 → 标记今日完成（补偿 automation 将跳过）
    _mark_done_today()

    should_push = (PUSH_POLICY == "always") or (PUSH_POLICY == "fail_only" and verdict == "fail")
    if should_push and verdict:
        icon = {"pass": "✅", "warn": "⚠️", "fail": "🔴"}.get(verdict, "ℹ️")
        md = (f"# {icon} 日报质检 {date or ''}\n"
              f"**结论：{verdict.upper()}**　问题 {len(issues)} 条\n\n"
              f"{summary[:600]}\n")
        if issues:
            md += "\n**问题清单：**\n"
            for it in issues[:5]:
                md += f"- [{it.get('dimension')}/{it.get('severity')}] {it.get('detail','')[:80]}\n"
        md += "\n_详情可问 knot：今天日报质检结果_"
        res = _push_wecom(md)
        print(f"  企微推送: {res}")
    else:
        print(f"  企微推送: 跳过（policy={PUSH_POLICY}, verdict={verdict}, webhook={'set' if WECOM_WEBHOOK else 'none'}）")

    print(f"[{ts}] daily_qc_runner done")
    return 0


if __name__ == "__main__":
    sys.exit(main())
