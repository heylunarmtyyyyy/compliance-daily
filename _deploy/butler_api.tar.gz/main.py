"""
butler_api/main.py — Compliance Butler API v0.2

合规管家智能体的本地能力接口层。流水线侧/knot 通过这些 HTTP 接口
调用本地数据与能力。本版本全部只读本地文件 + 包装现成脚本，
不依赖 knot 账号、不依赖公网部署，可本地 uvicorn 直接跑通。

启动：
    cd compliance-butler
    pip install fastapi uvicorn pyyaml
    uvicorn butler_api.main:app --host 127.0.0.1 --port 8901 --reload

自测：
    curl http://127.0.0.1:8901/api/health
    curl "http://127.0.0.1:8901/api/daily/status?date=2026-05-07"
    curl "http://127.0.0.1:8901/api/archive/search?q=COPPA&limit=5"

接口总览（8 个核心 + 健康检查）：
    GET  /api/health                     健康检查 + 数据源自检
    GET  /api/daily/status?date=         查某日日报产出状态
    GET  /api/daily/get?date=            读某日日报完整 MD
    GET  /api/sentinel/candidates        哨兵候选池
    GET  /api/archive/search?q=          全文检索历史日报/周报
    GET  /api/golden/list                列黄金集条目
    POST /api/corrections/log            写一条人工修正（替代 CLI）
    GET  /api/corrections/review         聚合最近 N 天修正
    POST /api/wecom/push                 推消息到企微（dry-run 默认开）
"""

import json
import os
import re
import glob
import time
import urllib.request
import urllib.error
import urllib.parse
import ssl
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# ---------- 路径配置 ----------
# 注意：本地 main.py 在 compliance-butler/butler_api/ 下（parent.parent.parent=项目根），
# 但灯塔机部署在 /opt/gcc/butler_api/ 下少一层包装目录。
# 因此周报/候选池等本地数据目录必须用环境变量 DAILY_V2_OUTPUT 显式指定，避免路径偏移。
# 灯塔机部署值：DAILY_V2_OUTPUT=/opt/gcc/game-compliance-daily-v2/output
BUTLER_ROOT = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BUTLER_ROOT.parent
_DEFAULT_V2 = PROJECT_ROOT / "game-compliance-daily-v2" / "output"
DAILY_V2_OUTPUT = Path(os.environ.get("DAILY_V2_OUTPUT", str(_DEFAULT_V2)))
DAILY_V1_OUTPUT = Path(os.environ.get("DAILY_V1_OUTPUT", str(PROJECT_ROOT / "game-compliance-daily" / "output")))
CORRECTIONS = BUTLER_ROOT / "corrections" / "corrections.jsonl"
PENDING = BUTLER_ROOT / "corrections" / "pending_rules.jsonl"
GOLDEN_DIR = BUTLER_ROOT / "golden_set"

DAILY_PREFIX = "游戏合规每日推送_"
CANDIDATES_PREFIX = "_daily_candidates_"

# ---------- 日报数据源（GitHub raw，按 <date>/ 文件夹）----------
# 数据分级：日报（低敏感）走 GitHub public；周报/告警（高敏感）走灯塔机本地。
# 环境变量可覆盖（部署时不改代码）：
#   DAILY_SOURCE = github | local   （默认 github）
#   GH_USER / GH_REPO / GH_BRANCH
#   GH_TOKEN（仅 private 仓库需要；public 留空）
DAILY_SOURCE = os.environ.get("DAILY_SOURCE", "github").lower()
GH_USER = os.environ.get("GH_USER", "heylunarmtyyyyy")
GH_REPO = os.environ.get("GH_REPO", "compliance-daily")
GH_BRANCH = os.environ.get("GH_BRANCH", "main")
GH_TOKEN = os.environ.get("GH_TOKEN", "")
GH_API = "https://api.github.com"
GH_RAW = "https://raw.githubusercontent.com"

_ctx = ssl.create_default_context()
# 简单内存缓存：{key: (ts, value)}，TTL 10 分钟，避免频繁打 GitHub
_CACHE = {}
_CACHE_TTL = 600


def _gh_headers():
    h = {"User-Agent": "compliance-butler-api", "Accept": "application/vnd.github+json"}
    if GH_TOKEN:
        h["Authorization"] = f"token {GH_TOKEN}"
    return h


def _gh_get(url, raw=False, cache=True):
    """GET GitHub（API 或 raw），带缓存。失败抛异常。中文路径自动编码。"""
    if cache and url in _CACHE:
        ts, val = _CACHE[url]
        if time.time() - ts < _CACHE_TTL:
            return val
    # 中文/非 ASCII 路径需编码（raw URL 文件名含中文）
    safe_url = urllib.parse.quote(url, safe=":/?=&%@")
    req = urllib.request.Request(safe_url, headers=_gh_headers(), method="GET")
    with urllib.request.urlopen(req, context=_ctx, timeout=15) as resp:
        data = resp.read().decode("utf-8", errors="ignore")
    val = data if raw else json.loads(data)
    if cache:
        _CACHE[url] = (time.time(), val)
    return val


def _gh_list_date_dirs():
    """列出仓库根下所有 YYYY-MM-DD 日期文件夹，降序。"""
    url = f"{GH_API}/repos/{GH_USER}/{GH_REPO}/contents/?ref={GH_BRANCH}"
    try:
        items = _gh_get(url)
    except Exception:
        return []
    dirs = [it["name"] for it in items
            if it.get("type") == "dir" and re.match(r"^\d{4}-\d{2}-\d{2}$", it.get("name", ""))]
    return sorted(dirs, reverse=True)


def _gh_daily_md_url(date):
    return f"{GH_RAW}/{GH_USER}/{GH_REPO}/{GH_BRANCH}/{date}/{DAILY_PREFIX}{date}.md"


def _read_daily_md(date):
    """读某日日报 MD，返回 (text, source_str) 或 (None, None)。"""
    if DAILY_SOURCE == "github":
        try:
            text = _gh_get(_gh_daily_md_url(date), raw=True)
            return text, f"github:{date}/{DAILY_PREFIX}{date}.md"
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None, None
        except Exception:
            pass
    # local fallback
    md_path = DAILY_V2_OUTPUT / f"{DAILY_PREFIX}{date}.md"
    if md_path.exists():
        return md_path.read_text(encoding="utf-8", errors="ignore"), str(md_path)
    return None, None


app = FastAPI(title="Compliance Butler API", version="0.3.0")


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ============================================================
# 健康检查
# ============================================================
@app.get("/api/health")
def health():
    """健康检查 + 数据源自检"""
    corrections_count = 0
    if CORRECTIONS.exists():
        with open(CORRECTIONS, encoding="utf-8") as f:
            corrections_count = sum(1 for ln in f if ln.strip())

    daily_source_info = {"mode": DAILY_SOURCE}
    if DAILY_SOURCE == "github":
        dirs = _gh_list_date_dirs()
        daily_source_info.update({
            "repo": f"{GH_USER}/{GH_REPO}@{GH_BRANCH}",
            "date_dirs_found": len(dirs),
            "latest": dirs[0] if dirs else None,
            "token": "set" if GH_TOKEN else "none(public)",
        })
    else:
        local_count = len(glob.glob(str(DAILY_V2_OUTPUT / f"{DAILY_PREFIX}*.md")))
        daily_source_info.update({
            "local_dir": str(DAILY_V2_OUTPUT),
            "daily_reports_found": local_count,
        })

    return {
        "status": "ok",
        "version": "0.3.0",
        "daily_source": daily_source_info,
        "local": {
            "candidate_pools": len(glob.glob(str(DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}*.json"))),
            "corrections_logged": corrections_count,
        },
        "ts": now_iso(),
    }


# ============================================================
# 日报状态
# ============================================================
@app.get("/api/daily/status")
def daily_status(date: str = Query(..., description="YYYY-MM-DD")):
    """查某日日报产出状态：MD 是否生成（GitHub）、候选池是否存在（本地）、各项统计"""
    text, src = _read_daily_md(date)
    cand_path = DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}{date}.json"

    result = {
        "date": date,
        "report_exists": text is not None,
        "report_source": src,
        "candidates_exists": cand_path.exists(),
    }
    if text is not None:
        result["report_size_chars"] = len(text)
        result["p0_count"] = len(re.findall(r"\bP0\b", text))
        result["p1_count"] = len(re.findall(r"\bP1\b", text))
        result["p2_count"] = len(re.findall(r"\bP2\b", text))
    if cand_path.exists():
        try:
            cand = json.loads(cand_path.read_text(encoding="utf-8"))
            result["candidates_summary"] = {
                "queries_executed": cand.get("queries_executed"),
                "raw_results": cand.get("raw_results"),
                "after_dedup": cand.get("after_dedup"),
                "by_priority": cand.get("by_priority"),
                "by_tencent": cand.get("by_tencent"),
            }
        except Exception as e:
            result["candidates_parse_error"] = str(e)
    return result


# ============================================================
# 日报全文
# ============================================================
@app.get("/api/daily/get")
def daily_get(date: str = Query(..., description="YYYY-MM-DD")):
    """读某日日报完整 MD 正文（GitHub raw，本地 fallback）"""
    text, src = _read_daily_md(date)
    if text is None:
        raise HTTPException(404, f"日报不存在: {date}")
    return {"date": date, "source": src, "content": text}


# ============================================================
# 哨兵候选池
# ============================================================
@app.get("/api/sentinel/candidates")
def sentinel_candidates(date: Optional[str] = Query(None, description="YYYY-MM-DD，省略取最新")):
    """读哨兵/日报候选池"""
    if date:
        cand_path = DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}{date}.json"
    else:
        pools = sorted(glob.glob(str(DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}*.json")))
        if not pools:
            raise HTTPException(404, "无候选池数据")
        cand_path = Path(pools[-1])
    if not cand_path.exists():
        raise HTTPException(404, f"候选池不存在: {date}")
    return json.loads(cand_path.read_text(encoding="utf-8"))


# ============================================================
# 历史日报全文检索
# ============================================================
@app.get("/api/archive/search")
def archive_search(
    q: str = Query(..., description="检索关键词"),
    limit: int = Query(10, description="最多返回条数"),
    scope: str = Query("all", description="all|daily|weekly"),
    days: int = Query(30, description="GitHub 模式下回溯最近 N 个日期文件夹"),
):
    """
    全文检索历史日报。
    - GitHub 模式（日报）：遍历最近 N 个日期文件夹读 MD 后 grep。
    - 周报（weekly）仍走本地（高敏感，不上 GitHub）。
    """
    hits = []
    q_lower = q.lower()

    # ---- 日报：GitHub 模式 ----
    if scope in ("all", "daily") and DAILY_SOURCE == "github":
        for date in _gh_list_date_dirs()[:days]:
            if len(hits) >= limit:
                break
            text, _ = _read_daily_md(date)
            if not text:
                continue
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if q_lower in line.lower():
                    s = max(0, i - 1); e = min(len(lines), i + 2)
                    hits.append({
                        "file": f"{date}/{DAILY_PREFIX}{date}.md",
                        "date": date,
                        "line_no": i + 1,
                        "snippet": "\n".join(lines[s:e]).strip()[:300],
                    })
                    if len(hits) >= limit:
                        break
    # ---- 日报：本地 fallback ----
    elif scope in ("all", "daily"):
        for fp in sorted(glob.glob(str(DAILY_V2_OUTPUT / f"{DAILY_PREFIX}*.md")), reverse=True):
            if len(hits) >= limit:
                break
            try:
                text = Path(fp).read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if q_lower in line.lower():
                    s = max(0, i - 1); e = min(len(lines), i + 2)
                    hits.append({"file": os.path.basename(fp), "line_no": i + 1,
                                 "snippet": "\n".join(lines[s:e]).strip()[:300]})
                    if len(hits) >= limit:
                        break

    # ---- 周报：始终本地（高敏感）----
    if scope in ("all", "weekly") and len(hits) < limit:
        for fp in sorted(glob.glob(str(DAILY_V2_OUTPUT / "GCC合规新闻每周导读_*.md")), reverse=True):
            if len(hits) >= limit:
                break
            try:
                text = Path(fp).read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if q_lower in line.lower():
                    s = max(0, i - 1); e = min(len(lines), i + 2)
                    hits.append({"file": os.path.basename(fp), "line_no": i + 1,
                                 "snippet": "\n".join(lines[s:e]).strip()[:300]})
                    if len(hits) >= limit:
                        break

    return {"query": q, "scope": scope, "source": DAILY_SOURCE,
            "hit_count": len(hits), "hits": hits}


# ============================================================
# 黄金集列表
# ============================================================
@app.get("/api/golden/list")
def golden_list():
    """列出黄金集所有 batch 文件与条目数"""
    batches = []
    for fp in sorted(glob.glob(str(GOLDEN_DIR / "*.yaml")) + glob.glob(str(GOLDEN_DIR / "*.yml"))):
        try:
            import yaml
            data = yaml.safe_load(Path(fp).read_text(encoding="utf-8"))
            count = len(data) if isinstance(data, list) else len(data.get("samples", []))
        except Exception:
            count = -1
        batches.append({"file": os.path.basename(fp), "sample_count": count})
    return {"golden_dir": str(GOLDEN_DIR), "batches": batches}


# ============================================================
# 写修正（替代 CLI，给 portal/企微 用）
# ============================================================
class CorrectionIn(BaseModel):
    type: str
    item_id: str
    original: str
    corrected: str
    reason: str
    scenario: str = "daily"
    item_url: str = ""
    item_title: str = ""
    model_confidence: Optional[float] = None
    model_reason: str = ""


VALID_TYPES = {"p_level", "topic", "juris", "tencent_mark", "source_grade",
               "drop", "add_missing", "style", "merge"}


@app.post("/api/corrections/log")
def corrections_log(c: CorrectionIn):
    """写一条人工修正到 corrections.jsonl"""
    if c.type not in VALID_TYPES:
        raise HTTPException(400, f"type 必须是 {VALID_TYPES} 之一")
    record = {
        "ts": now_iso(),
        "type": c.type,
        "scenario": c.scenario,
        "item_id": c.item_id,
        "item_url": c.item_url,
        "item_title": c.item_title,
        "field": c.type,
        "original": c.original,
        "corrected": c.corrected,
        "reason": c.reason,
        "corrector": "api",
        "model_confidence": c.model_confidence,
        "model_reason": c.model_reason,
    }
    CORRECTIONS.parent.mkdir(parents=True, exist_ok=True)
    with open(CORRECTIONS, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    return {"status": "ok", "logged": record}


# ============================================================
# 聚合修正
# ============================================================
@app.get("/api/corrections/review")
def corrections_review(days: int = Query(7, description="聚合最近 N 天")):
    """聚合最近 N 天修正，按 type 分类统计"""
    if not CORRECTIONS.exists():
        return {"days": days, "total": 0, "by_type": {}, "items": []}
    cutoff = datetime.now(timezone.utc).timestamp() - days * 86400
    counts, items = {}, []
    with open(CORRECTIONS, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            try:
                ts = datetime.fromisoformat(rec["ts"].replace("Z", "+00:00")).timestamp()
            except Exception:
                continue
            if ts < cutoff:
                continue
            t = rec.get("type", "unknown")
            counts[t] = counts.get(t, 0) + 1
            items.append(rec)
    return {
        "days": days,
        "total": sum(counts.values()),
        "by_type": dict(sorted(counts.items(), key=lambda kv: -kv[1])),
        "items": items[-20:],
    }


# ============================================================
# 企微推送（dry-run 默认开，防误推）
# ============================================================
class WecomPushIn(BaseModel):
    content: str
    msgtype: str = "markdown"
    channel: str = "default"
    dry_run: bool = True


@app.post("/api/wecom/push")
def wecom_push(p: WecomPushIn):
    """
    推消息到企微。默认 dry_run=True 只回显不真推，
    防止测试期误发到合规群。真推时 dry_run=False。
    实际推送包装 game-compliance-shared/wecom_push.py。
    """
    if p.dry_run:
        return {
            "status": "dry_run",
            "would_push": {"channel": p.channel, "msgtype": p.msgtype,
                           "content_preview": p.content[:200]},
            "note": "dry_run=True 未真推。真推请传 dry_run=false",
        }
    try:
        import sys
        sys.path.insert(0, str(PROJECT_ROOT / "game-compliance-shared"))
        import wecom_push as wp  # noqa
        # 具体函数名按 wecom_push.py 实际暴露调整
        result = {"status": "pushed", "note": "已调用 wecom_push（按实际函数签名对接）"}
        return result
    except Exception as e:
        raise HTTPException(500, f"企微推送失败: {e}")


@app.get("/")
def root():
    return JSONResponse({
        "service": "Compliance Butler API",
        "version": "0.2.0",
        "docs": "/docs",
        "health": "/api/health",
    })
