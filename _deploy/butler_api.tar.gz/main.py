"""
butler_api/main.py — Compliance Butler API v0.2

合规管家智能体的本地能力接口层。流水线侧/knot 通过这些 HTTP 接口
调用本地数据与能力。本版本全部只读本地文件 + 包装现成脚本，
不依赖 knot 账号、不依赖公网部署，可本地 uvicorn 直接跑通。

启动：
    cd compliance-butler
    pip install fastapi uvicorn pyyaml
    uvicorn butler_api.main:app --host 127.0.0.1 --port 8901 --reload

自测：
    curl http://127.0.0.1:8901/api/health
    curl "http://127.0.0.1:8901/api/daily/status?date=2026-05-07"
    curl "http://127.0.0.1:8901/api/archive/search?q=COPPA&limit=5"

接口总览（8 个核心 + 健康检查）：
    GET  /api/health                     健康检查 + 数据源自检
    GET  /api/daily/status?date=         查某日日报产出状态
    GET  /api/daily/get?date=            读某日日报完整 MD
    GET  /api/sentinel/candidates        哨兵候选池
    GET  /api/archive/search?q=          全文检索历史日报/周报
    GET  /api/golden/list                列黄金集条目
    POST /api/corrections/log            写一条人工修正（替代 CLI）
    GET  /api/corrections/review         聚合最近 N 天修正
    POST /api/wecom/push                 推消息到企微（dry-run 默认开）
"""

import json
import os
import re
import glob
import time
import urllib.request
import urllib.error
import urllib.parse
import ssl
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# ---------- 路径配置 ----------
# 注意：本地 main.py 在 compliance-butler/butler_api/ 下（parent.parent.parent=项目根），
# 但灯塔机部署在 /opt/gcc/butler_api/ 下少一层包装目录。
# 因此周报/候选池等本地数据目录必须用环境变量 DAILY_V2_OUTPUT 显式指定，避免路径偏移。
# 灯塔机部署值：DAILY_V2_OUTPUT=/opt/gcc/game-compliance-daily-v2/output
BUTLER_ROOT = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BUTLER_ROOT.parent
_DEFAULT_V2 = PROJECT_ROOT / "game-compliance-daily-v2" / "output"
DAILY_V2_OUTPUT = Path(os.environ.get("DAILY_V2_OUTPUT", str(_DEFAULT_V2)))
DAILY_V1_OUTPUT = Path(os.environ.get("DAILY_V1_OUTPUT", str(PROJECT_ROOT / "game-compliance-daily" / "output")))
CORRECTIONS = BUTLER_ROOT / "corrections" / "corrections.jsonl"
PENDING = BUTLER_ROOT / "corrections" / "pending_rules.jsonl"
LEARNING = BUTLER_ROOT / "learning"
GOLDEN_DIR = BUTLER_ROOT / "golden_set"

DAILY_PREFIX = "游戏合规每日推送_"
CANDIDATES_PREFIX = "_daily_candidates_"

# ---------- 日报数据源（GitHub raw，按 <date>/ 文件夹）----------
# 数据分级：日报（低敏感）走 GitHub public；周报/告警（高敏感）走灯塔机本地。
# 环境变量可覆盖（部署时不改代码）：
#   DAILY_SOURCE = github | local   （默认 github）
#   GH_USER / GH_REPO / GH_BRANCH
#   GH_TOKEN（仅 private 仓库需要；public 留空）
DAILY_SOURCE = os.environ.get("DAILY_SOURCE", "github").lower()
GH_USER = os.environ.get("GH_USER", "heylunarmtyyyyy")
GH_REPO = os.environ.get("GH_REPO", "compliance-daily")
GH_BRANCH = os.environ.get("GH_BRANCH", "main")
GH_TOKEN = os.environ.get("GH_TOKEN", "")
GH_API = "https://api.github.com"
GH_RAW = "https://raw.githubusercontent.com"

# ---------- 周报数据源（高敏感 → private 仓库，带 token）----------
# 周报含腾讯 Direct 判定/内部观点，绝不上 public 仓库。
# 默认走 private 仓库 compliance-private 的 weekly/ 目录（raw 必须带 token）。
# 环境变量可覆盖（部署时不改代码）：
#   WEEKLY_SOURCE = github | local   （默认 github=私有库；local=灯塔机本地兜底）
#   WK_USER / WK_REPO / WK_BRANCH / WK_TOKEN / WK_DIR
WEEKLY_SOURCE = os.environ.get("WEEKLY_SOURCE", "github").lower()
WK_USER = os.environ.get("WK_USER", "heylunarmtyyyyy")
WK_REPO = os.environ.get("WK_REPO", "compliance-private")
WK_BRANCH = os.environ.get("WK_BRANCH", "main")
WK_TOKEN = os.environ.get("WK_TOKEN", "")  # private 仓库必须配
WK_DIR = os.environ.get("WK_DIR", "weekly")  # 仓库内周报目录
WEEKLY_PREFIX = "GCC合规新闻每周导读_"

# ---------- 告警两级队列数据源（同 private 仓库，带 token）----------
# 告警系统两级过滤（方案 T2）：
#   第一级 哨兵粗筛 → alerts/pending/YYYY-MM-DD.json（待侦察队列）
#   第二级 knot 校准 → alerts/verified/YYYY-MM-DD.json（已核实告警，才推送）
# 复用 WK_* 私有库凭证；目录可单独覆盖。
ALERTS_DIR = os.environ.get("ALERTS_DIR", "alerts")  # 仓库内告警根目录
ALERTS_PENDING_DIR = f"{ALERTS_DIR}/pending"
ALERTS_VERIFIED_DIR = f"{ALERTS_DIR}/verified"

_ctx = ssl.create_default_context()
# 简单内存缓存：{key: (ts, value)}，TTL 10 分钟，避免频繁打 GitHub
_CACHE = {}
_CACHE_TTL = 600


def _gh_headers():
    h = {"User-Agent": "compliance-butler-api", "Accept": "application/vnd.github+json"}
    if GH_TOKEN:
        h["Authorization"] = f"token {GH_TOKEN}"
    return h


def _gh_get(url, raw=False, cache=True):
    """GET GitHub（API 或 raw），带缓存。失败抛异常。中文路径自动编码。"""
    if cache and url in _CACHE:
        ts, val = _CACHE[url]
        if time.time() - ts < _CACHE_TTL:
            return val
    # 中文/非 ASCII 路径需编码（raw URL 文件名含中文）
    safe_url = urllib.parse.quote(url, safe=":/?=&%@")
    req = urllib.request.Request(safe_url, headers=_gh_headers(), method="GET")
    with urllib.request.urlopen(req, context=_ctx, timeout=15) as resp:
        data = resp.read().decode("utf-8", errors="ignore")
    val = data if raw else json.loads(data)
    if cache:
        _CACHE[url] = (time.time(), val)
    return val


def _gh_list_date_dirs():
    """列出仓库根下所有 YYYY-MM-DD 日期文件夹，降序。"""
    url = f"{GH_API}/repos/{GH_USER}/{GH_REPO}/contents/?ref={GH_BRANCH}"
    try:
        items = _gh_get(url)
    except Exception:
        return []
    dirs = [it["name"] for it in items
            if it.get("type") == "dir" and re.match(r"^\d{4}-\d{2}-\d{2}$", it.get("name", ""))]
    return sorted(dirs, reverse=True)


def _gh_daily_md_url(date):
    return f"{GH_RAW}/{GH_USER}/{GH_REPO}/{GH_BRANCH}/{date}/{DAILY_PREFIX}{date}.md"


def _read_daily_md(date):
    """读某日日报 MD，返回 (text, source_str) 或 (None, None)。"""
    if DAILY_SOURCE == "github":
        try:
            text = _gh_get(_gh_daily_md_url(date), raw=True)
            return text, f"github:{date}/{DAILY_PREFIX}{date}.md"
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None, None
        except Exception:
            pass
    # local fallback
    md_path = DAILY_V2_OUTPUT / f"{DAILY_PREFIX}{date}.md"
    if md_path.exists():
        return md_path.read_text(encoding="utf-8", errors="ignore"), str(md_path)
    return None, None


# ---------- 周报私有库数据访问 ----------
def _wk_headers():
    h = {"User-Agent": "compliance-butler-api", "Accept": "application/vnd.github+json"}
    if WK_TOKEN:
        h["Authorization"] = f"token {WK_TOKEN}"
    return h


def _wk_get(url, raw=False, cache=True):
    """GET 私有库（API 或 raw），带 token + 缓存。失败抛异常。"""
    if cache and url in _CACHE:
        ts, val = _CACHE[url]
        if time.time() - ts < _CACHE_TTL:
            return val
    safe_url = urllib.parse.quote(url, safe=":/?=&%@")
    req = urllib.request.Request(safe_url, headers=_wk_headers(), method="GET")
    with urllib.request.urlopen(req, context=_ctx, timeout=15) as resp:
        data = resp.read().decode("utf-8", errors="ignore")
    val = data if raw else json.loads(data)
    if cache:
        _CACHE[url] = (time.time(), val)
    return val


def _wk_list_files():
    """列出私有库 weekly/ 目录下所有周报 MD 文件名。失败返回 []。"""
    url = f"{GH_API}/repos/{WK_USER}/{WK_REPO}/contents/{WK_DIR}?ref={WK_BRANCH}"
    try:
        items = _wk_get(url)
    except Exception:
        return []
    return sorted(
        [it["name"] for it in items
         if it.get("type") == "file" and it.get("name", "").endswith(".md")
         and it.get("name", "").startswith(WEEKLY_PREFIX)],
        reverse=True,
    )


def _wk_raw_url(name):
    return f"{GH_RAW}/{WK_USER}/{WK_REPO}/{WK_BRANCH}/{WK_DIR}/{name}"


def _iter_weekly_docs():
    """统一周报迭代器：返回 [(filename, text), ...]，按文件名降序。
    优先私有库（github），失败/未配 token 时退灯塔机本地。"""
    if WEEKLY_SOURCE == "github":
        names = _wk_list_files()
        if names:
            out = []
            for name in names:
                try:
                    text = _wk_get(_wk_raw_url(name), raw=True)
                    out.append((name, text))
                except Exception:
                    continue
            if out:
                return out
    # local fallback（灯塔机本地）
    out = []
    for fp in sorted(glob.glob(str(DAILY_V2_OUTPUT / f"{WEEKLY_PREFIX}*.md")), reverse=True):
        try:
            out.append((os.path.basename(fp), Path(fp).read_text(encoding="utf-8", errors="ignore")))
        except Exception:
            continue
    return out


# ---------- 告警两级队列数据访问（private 仓库 alerts/）----------
def _alerts_list(subdir):
    """列出 alerts/<subdir>/ 下所有 *.json 文件名，降序。失败返回 []。"""
    url = f"{GH_API}/repos/{WK_USER}/{WK_REPO}/contents/{subdir}?ref={WK_BRANCH}"
    try:
        items = _wk_get(url)
    except Exception:
        return []
    return sorted(
        [it["name"] for it in items
         if it.get("type") == "file" and it.get("name", "").endswith(".json")],
        reverse=True,
    )


def _alerts_read(subdir, date=None):
    """读 alerts/<subdir>/<date>.json；date 省略取最新。返回 (data, filename) 或 (None, None)。"""
    names = _alerts_list(subdir)
    if not names:
        return None, None
    if date:
        target = f"{date}.json"
        if target not in names:
            return None, None
        name = target
    else:
        name = names[0]
    raw_url = f"{GH_RAW}/{WK_USER}/{WK_REPO}/{WK_BRANCH}/{subdir}/{name}"
    try:
        text = _wk_get(raw_url, raw=True)
        return json.loads(text), name
    except Exception:
        return None, None


def _alerts_write(subdir, date, payload):
    """写 alerts/<subdir>/<date>.json 到私有库（Contents API PUT，覆盖）。返回 (ok, msg)。"""
    if not WK_TOKEN:
        return False, "WK_TOKEN 未配置，无法写入私有库"
    gh_path = f"{subdir}/{date}.json"
    api_url = f"{GH_API}/repos/{WK_USER}/{WK_REPO}/contents/{urllib.parse.quote(gh_path)}"
    # 查 sha
    sha = None
    try:
        existing = _wk_get(f"{api_url}?ref={WK_BRANCH}", cache=False)
        sha = existing.get("sha")
    except Exception:
        pass
    import base64 as _b64
    content_b64 = _b64.b64encode(
        json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    ).decode()
    body = {"message": f"alerts {subdir}: {date}", "content": content_b64, "branch": WK_BRANCH}
    if sha:
        body["sha"] = sha
    data = json.dumps(body).encode()
    req = urllib.request.Request(api_url, data=data, headers=_wk_headers(), method="PUT")
    try:
        with urllib.request.urlopen(req, context=_ctx, timeout=20) as resp:
            ok = resp.status in (200, 201)
        # 写后让相关缓存失效
        _CACHE.pop(f"{GH_API}/repos/{WK_USER}/{WK_REPO}/contents/{subdir}?ref={WK_BRANCH}", None)
        return ok, "ok"
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:200]}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


app = FastAPI(title="Compliance Butler API", version="0.8.0")


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _iso_week_tag(dt=None):
    dt = dt or datetime.now(timezone.utc)
    y, w, _ = dt.isocalendar()
    return f"{y}W{w:02d}"


# ============================================================
# 健康检查
# ============================================================
@app.get("/api/health")
def health():
    """健康检查 + 数据源自检"""
    corrections_count = 0
    if CORRECTIONS.exists():
        with open(CORRECTIONS, encoding="utf-8") as f:
            corrections_count = sum(1 for ln in f if ln.strip())

    daily_source_info = {"mode": DAILY_SOURCE}
    if DAILY_SOURCE == "github":
        dirs = _gh_list_date_dirs()
        daily_source_info.update({
            "repo": f"{GH_USER}/{GH_REPO}@{GH_BRANCH}",
            "date_dirs_found": len(dirs),
            "latest": dirs[0] if dirs else None,
            "token": "set" if GH_TOKEN else "none(public)",
        })
    else:
        local_count = len(glob.glob(str(DAILY_V2_OUTPUT / f"{DAILY_PREFIX}*.md")))
        daily_source_info.update({
            "local_dir": str(DAILY_V2_OUTPUT),
            "daily_reports_found": local_count,
        })

    return {
        "status": "ok",
        "version": "0.8.0",
        "daily_source": daily_source_info,
        "weekly_source": {
            "mode": WEEKLY_SOURCE,
            "repo": f"{WK_USER}/{WK_REPO}@{WK_BRANCH}" if WEEKLY_SOURCE == "github" else str(DAILY_V2_OUTPUT),
            "weekly_count": len(_wk_list_files()) if WEEKLY_SOURCE == "github" else
                            len(glob.glob(str(DAILY_V2_OUTPUT / f"{WEEKLY_PREFIX}*.md"))),
            "token": "set" if WK_TOKEN else "none",
        },
        "alerts": {
            "pending_dates": len(_alerts_list(ALERTS_PENDING_DIR)),
            "verified_dates": len(_alerts_list(ALERTS_VERIFIED_DIR)),
            "qc_reports": len(_alerts_list("daily_qc")),
        },
        "local": {
            "candidate_pools": len(glob.glob(str(DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}*.json"))),
            "corrections_logged": corrections_count,
        },
        "ts": now_iso(),
    }


# ============================================================
# 日报状态
# ============================================================
@app.get("/api/daily/status")
def daily_status(date: str = Query(..., description="YYYY-MM-DD")):
    """查某日日报产出状态：MD 是否生成（GitHub）、候选池是否存在（本地）、各项统计"""
    text, src = _read_daily_md(date)
    cand_path = DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}{date}.json"

    result = {
        "date": date,
        "report_exists": text is not None,
        "report_source": src,
        "candidates_exists": cand_path.exists(),
    }
    if text is not None:
        result["report_size_chars"] = len(text)
        result["p0_count"] = len(re.findall(r"\bP0\b", text))
        result["p1_count"] = len(re.findall(r"\bP1\b", text))
        result["p2_count"] = len(re.findall(r"\bP2\b", text))
    if cand_path.exists():
        try:
            cand = json.loads(cand_path.read_text(encoding="utf-8"))
            result["candidates_summary"] = {
                "queries_executed": cand.get("queries_executed"),
                "raw_results": cand.get("raw_results"),
                "after_dedup": cand.get("after_dedup"),
                "by_priority": cand.get("by_priority"),
                "by_tencent": cand.get("by_tencent"),
            }
        except Exception as e:
            result["candidates_parse_error"] = str(e)
    return result


# ============================================================
# 日报全文
# ============================================================
@app.get("/api/daily/get")
def daily_get(date: str = Query(..., description="YYYY-MM-DD")):
    """读某日日报完整 MD 正文（GitHub raw，本地 fallback）"""
    text, src = _read_daily_md(date)
    if text is None:
        raise HTTPException(404, f"日报不存在: {date}")
    return {"date": date, "source": src, "content": text}


# ============================================================
# 周报：列表 + 全文（私有库优先，本地兜底）
# ============================================================
@app.get("/api/weekly/list")
def weekly_list():
    """列出所有可用周报（文件名 + 周期），按时间降序。"""
    docs = _iter_weekly_docs()
    items = []
    for name, _ in docs:
        # 文件名形如 GCC合规新闻每周导读_2026.5.15-2026.5.21.md
        period = name[len(WEEKLY_PREFIX):].rsplit(".md", 1)[0] if name.startswith(WEEKLY_PREFIX) else name
        items.append({"file": name, "period": period})
    return {"weekly_source": WEEKLY_SOURCE, "count": len(items), "items": items}


@app.get("/api/weekly/get")
def weekly_get(period: str = Query(..., description="周期串，如 2026.5.15-2026.5.21；支持模糊匹配文件名子串")):
    """读某期周报完整 MD 正文。period 为文件名中的周期串，支持子串模糊匹配。"""
    docs = _iter_weekly_docs()
    # 精确：文件名含该 period 串；多匹配取第一个（已降序）
    for name, text in docs:
        if period in name:
            return {"period": period, "file": name,
                    "weekly_source": WEEKLY_SOURCE, "content": text}
    raise HTTPException(404, f"周报不存在: {period}（可用 /api/weekly/list 查看全部周期）")


# ============================================================
# 告警两级队列：哨兵粗筛(pending) → knot 校准(verified)
# ============================================================
@app.get("/api/sentinel/candidates")
def sentinel_candidates(date: Optional[str] = Query(None, description="YYYY-MM-DD，省略取最新")):
    """
    读哨兵【待侦察队列】（pending）—— knot 侦察校准的输入。
    数据源：private 仓库 alerts/pending/<date>.json（哨兵每轮粗筛后 push）。
    兼容兜底：私有库无 pending 时，回退读本地日报候选池 _daily_candidates_*.json。
    """
    data, name = _alerts_read(ALERTS_PENDING_DIR, date)
    if data is not None:
        return {"source": f"private:{ALERTS_PENDING_DIR}/{name}", "queue": "pending", "data": data}
    # 兜底：本地日报候选池（旧行为）
    if date:
        cand_path = DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}{date}.json"
    else:
        pools = sorted(glob.glob(str(DAILY_V2_OUTPUT / f"{CANDIDATES_PREFIX}*.json")))
        cand_path = Path(pools[-1]) if pools else None
    if cand_path and cand_path.exists():
        return {"source": f"local:{cand_path.name}", "queue": "daily_candidates",
                "data": json.loads(cand_path.read_text(encoding="utf-8"))}
    raise HTTPException(404, "无待侦察队列，也无本地候选池数据")


@app.post("/api/sentinel/verify")
def sentinel_verify(payload: dict):
    """
    knot 侦察校准后写回【已核实告警】（verified）。
    body: {"date":"YYYY-MM-DD", "items":[...], "summary":"...", "reviewed_by":"knot", ...}
    写入 private 仓库 alerts/verified/<date>.json。
    """
    date = payload.get("date") or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    payload.setdefault("verified_at", now_iso())
    payload.setdefault("reviewed_by", "knot")
    ok, msg = _alerts_write(ALERTS_VERIFIED_DIR, date, payload)
    if not ok:
        raise HTTPException(500, f"写入 verified 失败: {msg}")
    return {"status": "ok", "date": date,
            "path": f"{ALERTS_VERIFIED_DIR}/{date}.json",
            "item_count": len(payload.get("items", []))}


@app.get("/api/alerts/verified")
def alerts_verified(date: Optional[str] = Query(None, description="YYYY-MM-DD，省略取最新")):
    """读【已核实告警】（verified）—— 供推送/查询/留痕。"""
    data, name = _alerts_read(ALERTS_VERIFIED_DIR, date)
    if data is None:
        raise HTTPException(404, f"无已核实告警: {date or '(最新)'}")
    return {"source": f"private:{ALERTS_VERIFIED_DIR}/{name}", "queue": "verified", "data": data}


@app.get("/api/alerts/list")
def alerts_list(queue: str = Query("pending", description="pending|verified")):
    """列出某队列下所有日期文件（pending 或 verified）。"""
    subdir = ALERTS_PENDING_DIR if queue == "pending" else ALERTS_VERIFIED_DIR
    names = _alerts_list(subdir)
    return {"queue": queue, "count": len(names),
            "dates": [n.rsplit(".json", 1)[0] for n in names]}


# ============================================================
# 日报每日质检（QC）：自动质检报告读写（private 仓库 daily_qc/）
# ============================================================
QC_DIR = os.environ.get("QC_DIR", "daily_qc")


@app.post("/api/daily/qc_submit")
def daily_qc_submit(payload: dict):
    """
    写当天日报【质检报告】到私有库 daily_qc/<date>.json。
    由 automation 每日定时唤醒的质检流程调用。
    body 建议: {"date":"YYYY-MM-DD", "verdict":"pass|warn|fail",
                "issues":[{dimension,severity,item,detail,suggestion}],
                "stats":{checked,passed,warned,failed}, "summary":"..."}
    """
    date = payload.get("date") or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    payload.setdefault("qc_at", now_iso())
    payload.setdefault("qc_by", "automation")
    ok, msg = _alerts_write(QC_DIR, date, payload)
    if not ok:
        raise HTTPException(500, f"写入质检报告失败: {msg}")
    return {"status": "ok", "date": date, "path": f"{QC_DIR}/{date}.json",
            "issue_count": len(payload.get("issues", []))}


@app.get("/api/daily/qc_get")
def daily_qc_get(date: Optional[str] = Query(None, description="YYYY-MM-DD，省略取最新")):
    """读某天日报质检报告（private 仓库 daily_qc/）。供 knot 查阅质检结果。"""
    data, name = _alerts_read(QC_DIR, date)
    if data is None:
        raise HTTPException(404, f"无质检报告: {date or '(最新)'}")
    return {"source": f"private:{QC_DIR}/{name}", "data": data}


@app.get("/api/daily/qc_list")
def daily_qc_list():
    """列出所有已有质检报告的日期。"""
    names = _alerts_list(QC_DIR)
    return {"count": len(names), "dates": [n.rsplit(".json", 1)[0] for n in names]}


# ============================================================
# 历史日报全文检索
# ============================================================
@app.get("/api/archive/search")
def archive_search(
    q: str = Query(..., description="检索关键词"),
    limit: int = Query(10, description="最多返回条数"),
    scope: str = Query("all", description="all|daily|weekly"),
    days: int = Query(30, description="GitHub 模式下回溯最近 N 个日期文件夹"),
):
    """
    全文检索历史日报。
    - GitHub 模式（日报）：遍历最近 N 个日期文件夹读 MD 后 grep。
    - 周报（weekly）仍走本地（高敏感，不上 GitHub）。
    """
    hits = []
    q_lower = q.lower()

    # ---- 日报：GitHub 模式 ----
    if scope in ("all", "daily") and DAILY_SOURCE == "github":
        for date in _gh_list_date_dirs()[:days]:
            if len(hits) >= limit:
                break
            text, _ = _read_daily_md(date)
            if not text:
                continue
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if q_lower in line.lower():
                    s = max(0, i - 1); e = min(len(lines), i + 2)
                    hits.append({
                        "file": f"{date}/{DAILY_PREFIX}{date}.md",
                        "date": date,
                        "line_no": i + 1,
                        "snippet": "\n".join(lines[s:e]).strip()[:300],
                    })
                    if len(hits) >= limit:
                        break
    # ---- 日报：本地 fallback ----
    elif scope in ("all", "daily"):
        for fp in sorted(glob.glob(str(DAILY_V2_OUTPUT / f"{DAILY_PREFIX}*.md")), reverse=True):
            if len(hits) >= limit:
                break
            try:
                text = Path(fp).read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if q_lower in line.lower():
                    s = max(0, i - 1); e = min(len(lines), i + 2)
                    hits.append({"file": os.path.basename(fp), "line_no": i + 1,
                                 "snippet": "\n".join(lines[s:e]).strip()[:300]})
                    if len(hits) >= limit:
                        break

    # ---- 周报：私有库优先（高敏感，private 仓库带 token），本地兜底 ----
    if scope in ("all", "weekly") and len(hits) < limit:
        for name, text in _iter_weekly_docs():
            if len(hits) >= limit:
                break
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if q_lower in line.lower():
                    s = max(0, i - 1); e = min(len(lines), i + 2)
                    hits.append({"file": name, "line_no": i + 1,
                                 "snippet": "\n".join(lines[s:e]).strip()[:300]})
                    if len(hits) >= limit:
                        break

    return {"query": q, "scope": scope, "source": DAILY_SOURCE,
            "weekly_source": WEEKLY_SOURCE,
            "hit_count": len(hits), "hits": hits}


# ============================================================
# 黄金集列表
# ============================================================
@app.get("/api/golden/list")
def golden_list():
    """列出黄金集所有 batch 文件与条目数"""
    batches = []
    for fp in sorted(glob.glob(str(GOLDEN_DIR / "*.yaml")) + glob.glob(str(GOLDEN_DIR / "*.yml"))):
        try:
            import yaml
            data = yaml.safe_load(Path(fp).read_text(encoding="utf-8"))
            count = len(data) if isinstance(data, list) else len(data.get("samples", []))
        except Exception:
            count = -1
        batches.append({"file": os.path.basename(fp), "sample_count": count})
    return {"golden_dir": str(GOLDEN_DIR), "batches": batches}


# ============================================================
# 写修正（替代 CLI，给 portal/企微 用）
# ============================================================
class CorrectionIn(BaseModel):
    type: str
    item_id: str
    original: str
    corrected: str
    reason: str
    scenario: str = "daily"
    item_url: str = ""
    item_title: str = ""
    model_confidence: Optional[float] = None
    model_reason: str = ""


VALID_TYPES = {"p_level", "topic", "juris", "tencent_mark", "source_grade",
               "drop", "add_missing", "style", "merge"}


@app.post("/api/corrections/log")
def corrections_log(c: CorrectionIn):
    """写一条人工修正到 corrections.jsonl"""
    if c.type not in VALID_TYPES:
        raise HTTPException(400, f"type 必须是 {VALID_TYPES} 之一")
    record = {
        "ts": now_iso(),
        "type": c.type,
        "scenario": c.scenario,
        "item_id": c.item_id,
        "item_url": c.item_url,
        "item_title": c.item_title,
        "field": c.type,
        "original": c.original,
        "corrected": c.corrected,
        "reason": c.reason,
        "corrector": "api",
        "model_confidence": c.model_confidence,
        "model_reason": c.model_reason,
    }
    CORRECTIONS.parent.mkdir(parents=True, exist_ok=True)
    with open(CORRECTIONS, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    return {"status": "ok", "logged": record}


# ============================================================
# 聚合修正
# ============================================================
@app.get("/api/corrections/review")
def corrections_review(days: int = Query(7, description="聚合最近 N 天")):
    """聚合最近 N 天修正，按 type 分类统计"""
    if not CORRECTIONS.exists():
        return {"days": days, "total": 0, "by_type": {}, "items": []}
    cutoff = datetime.now(timezone.utc).timestamp() - days * 86400
    counts, items = {}, []
    with open(CORRECTIONS, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            try:
                ts = datetime.fromisoformat(rec["ts"].replace("Z", "+00:00")).timestamp()
            except Exception:
                continue
            if ts < cutoff:
                continue
            t = rec.get("type", "unknown")
            counts[t] = counts.get(t, 0) + 1
            items.append(rec)
    return {
        "days": days,
        "total": sum(counts.values()),
        "by_type": dict(sorted(counts.items(), key=lambda kv: -kv[1])),
        "items": items[-20:],
    }


# ============================================================
# knot 写回：提议规则 / 提议关键词（只进候选区，待用户审批）
# ============================================================
class ProposeRuleIn(BaseModel):
    proposed_rule: str           # knot 提议的规则正文
    rule_type: str = "general"   # p_level|topic|juris|tencent_mark|source_grade|drop|merge|general
    trigger_pattern: str = ""    # 触发场景描述
    evidence: str = ""           # 依据（讨论/案例）
    expected_impact: str = ""    # 预期效果
    risk: str = ""               # 风险提示
    proposed_by: str = "knot"


class ProposeKeywordIn(BaseModel):
    keyword: str                 # 提议新增/调整的关键词
    action: str = "add"          # add|modify|remove
    theme: str = ""              # 所属板块
    reason: str = ""             # 理由
    proposed_by: str = "knot"


@app.post("/api/corrections/propose_rule")
def propose_rule(p: ProposeRuleIn):
    """
    knot 提议一条规则候选，写入 pending_rules.jsonl（status=pending_review）。
    护栏：只进候选区，不直接改生产规则/知识库。需用户用 butler_cli rules approve 审批才生效。
    """
    # 取已有候选数生成 id
    existing = 0
    if PENDING.exists():
        with open(PENDING, encoding="utf-8") as f:
            existing = sum(1 for ln in f if ln.strip())
    week = datetime.now(timezone.utc).strftime("%Y-W%V")
    cid = f"rc-{week}-knot-{existing + 1:03d}"
    candidate = {
        "candidate_id": cid,
        "created_at": now_iso(),
        "type": p.rule_type,
        "trigger_pattern": p.trigger_pattern or "(knot 对话中提议)",
        "evidence_corrections": [],
        "evidence_note": p.evidence,
        "proposed_rule": p.proposed_rule,
        "expected_impact": p.expected_impact,
        "risk": p.risk or "需黄金集回归验证，避免过拟合",
        "golden_test_result": None,
        "status": "pending_review",
        "source": "knot_propose",
        "proposed_by": p.proposed_by,
        "decided_at": None,
        "decided_by": None,
    }
    PENDING.parent.mkdir(parents=True, exist_ok=True)
    with open(PENDING, "a", encoding="utf-8") as f:
        f.write(json.dumps(candidate, ensure_ascii=False) + "\n")
    return {"status": "ok", "candidate_id": cid,
            "note": "已写入规则候选区，待用户审批（butler_cli rules approve）后生效",
            "candidate": candidate}


@app.post("/api/sentinel/propose_keyword")
def propose_keyword(p: ProposeKeywordIn):
    """
    knot 提议哨兵关键词调整，写入 pending_rules.jsonl（type=keyword, status=pending_review）。
    护栏：只提议，不直接改 sentinel-keywords.json。
    """
    existing = 0
    if PENDING.exists():
        with open(PENDING, encoding="utf-8") as f:
            existing = sum(1 for ln in f if ln.strip())
    week = datetime.now(timezone.utc).strftime("%Y-W%V")
    cid = f"kw-{week}-knot-{existing + 1:03d}"
    candidate = {
        "candidate_id": cid,
        "created_at": now_iso(),
        "type": "keyword",
        "action": p.action,
        "keyword": p.keyword,
        "theme": p.theme,
        "proposed_rule": f"哨兵关键词 {p.action}: '{p.keyword}'（板块 {p.theme or '未指定'}）",
        "evidence_note": p.reason,
        "status": "pending_review",
        "source": "knot_propose",
        "proposed_by": p.proposed_by,
        "decided_at": None,
        "decided_by": None,
    }
    PENDING.parent.mkdir(parents=True, exist_ok=True)
    with open(PENDING, "a", encoding="utf-8") as f:
        f.write(json.dumps(candidate, ensure_ascii=False) + "\n")
    return {"status": "ok", "candidate_id": cid,
            "note": "已写入关键词候选区，待用户审批后生效",
            "candidate": candidate}


@app.get("/api/corrections/pending")
def corrections_pending(status: str = Query("pending_review", description="筛选状态，all=全部")):
    """列出规则候选区（pending_rules）。供用户/knot 查看待审批项。"""
    if not PENDING.exists():
        return {"count": 0, "items": []}
    items = []
    with open(PENDING, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if status == "all" or rec.get("status") == status:
                items.append(rec)
    return {"count": len(items), "status_filter": status, "items": items}


# ============================================================
# 审批：approve / reject 一条规则候选（更新 status + 落 learning/）
# ============================================================
# 护栏（与 butler_cli rules approve 等价，仅触发方式从 SSH 改为 knot 代执行）：
#   1. 只能处理 status=pending_review（pending）的候选，已决策的跳过；
#   2. 审批权归用户——knot 仅在用户明确说"我批准 xxx"时才代为调用本接口；
#      knot 不得自主审批（约束写在 MCP 工具描述里 + system_prompt）；
#   3. approve 后把规则追加到 learning/YYYY-WXX.md，作为已生效经验留痕。
class ApproveRuleIn(BaseModel):
    candidate_id: str            # 要审批的候选 id（rc-... / kw-...）
    decision: str = "approve"    # approve | reject
    reason: str = ""             # 决策理由（可选）
    decided_by: str = "user"     # 决策人（默认 user；knot 代执行时仍记 user）


def _rewrite_pending(records):
    """整体重写 pending_rules.jsonl"""
    PENDING.parent.mkdir(parents=True, exist_ok=True)
    with open(PENDING, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def _write_learning(candidate):
    """把已批准规则追加到 learning/YYYY-WXX.md（与 CLI _write_learning 对齐）"""
    week = _iso_week_tag()
    LEARNING.mkdir(parents=True, exist_ok=True)
    path = LEARNING / f"{week}.md"
    header_needed = not path.exists()
    with open(path, "a", encoding="utf-8") as f:
        if header_needed:
            f.write(f"# 学习沉淀 {week}\n\n")
            f.write("> 本周经用户审批通过的规则候选。每条对应 pending_rules 中一个 approved 项。\n\n")
        f.write(f"## {candidate['candidate_id']} · {candidate.get('type', 'general')}\n\n")
        f.write(f"- **触发模式**：{candidate.get('trigger_pattern', '')}\n")
        f.write(f"- **规则**：{candidate.get('proposed_rule', '')}\n")
        f.write(f"- **预期影响**：{candidate.get('expected_impact', '')}\n")
        f.write(f"- **风险**：{candidate.get('risk', '')}\n")
        f.write(f"- **批准时间**：{candidate.get('decided_at', '')}\n")
        f.write(f"- **证据条数**：{len(candidate.get('evidence_corrections', []))}\n\n")
    return str(path)


@app.post("/api/corrections/approve")
def corrections_approve(a: ApproveRuleIn):
    """
    审批一条规则候选：approve（批准→落 learning/）或 reject（拒绝→留痕反思）。
    把候选 status 从 pending_review 改为 approved/rejected，写回 pending_rules.jsonl。
    护栏：仅处理 pending_review 态；审批权归用户，knot 仅在用户明确批准时代为调用。
    """
    decision = (a.decision or "approve").lower().strip()
    if decision not in ("approve", "reject"):
        raise HTTPException(status_code=400, detail="decision 必须是 approve 或 reject")
    if not PENDING.exists():
        raise HTTPException(status_code=404, detail="pending_rules.jsonl 不存在，无候选可审批")

    records, target = [], None
    with open(PENDING, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("candidate_id") == a.candidate_id:
                target = rec
            records.append(rec)

    if target is None:
        raise HTTPException(status_code=404, detail=f"找不到候选 {a.candidate_id}")

    cur = target.get("status")
    if cur not in ("pending_review", "pending"):
        return {"status": "skipped",
                "candidate_id": a.candidate_id,
                "current_status": cur,
                "note": f"该候选当前状态已是 {cur}，非待审批态，跳过（防重复审批）"}

    target["decided_at"] = now_iso()
    target["decided_by"] = a.decided_by or "user"
    learning_path = None
    if decision == "approve":
        target["status"] = "approved"
        target["decision_reason"] = a.reason or "用户批准"
        _rewrite_pending(records)
        learning_path = _write_learning(target)
        note = "已批准并写入 learning/。提醒：knot 知识库 06_纠错沉淀/ 需后续同步此规则。"
    else:
        target["status"] = "rejected"
        target["decision_reason"] = a.reason or "用户拒绝"
        _rewrite_pending(records)
        note = "已拒绝。原因已留痕，供未来反思，不影响生产规则。"

    return {"status": "ok",
            "decision": decision,
            "candidate_id": a.candidate_id,
            "new_status": target["status"],
            "decision_reason": target["decision_reason"],
            "learning_path": learning_path,
            "note": note,
            "candidate": target}


@app.get("/api/rules/active")
def rules_active(rule_type: str = Query("all", description="按 type 筛选，all=全部")):
    """
    返回【已生效规则清单】——所有经用户审批通过（status=approved）的规则/关键词候选。
    这是 knot 做合规判断/日报质检/告警校准时应实时遵守的"增量规则层"，
    在 RAG 知识库（基线规则）之上叠加用户最新批准的修正。
    与知识库的关系：知识库=离线基线（季度人工维护）；本清单=即时增量（审批即生效，零重建索引）。
    """
    if not PENDING.exists():
        return {"count": 0, "rules": [], "by_type": {}, "ts": now_iso()}
    rules = []
    with open(PENDING, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("status") != "approved":
                continue
            if rule_type != "all" and rec.get("type") != rule_type:
                continue
            rules.append({
                "candidate_id": rec.get("candidate_id"),
                "type": rec.get("type"),
                "rule": rec.get("proposed_rule"),
                "trigger_pattern": rec.get("trigger_pattern", ""),
                "keyword": rec.get("keyword"),
                "theme": rec.get("theme"),
                "approved_at": rec.get("decided_at"),
                "approved_by": rec.get("decided_by"),
            })
    # 最新批准的排前面
    rules.sort(key=lambda r: r.get("approved_at") or "", reverse=True)
    by_type = {}
    for r in rules:
        by_type.setdefault(r["type"] or "general", []).append(r["candidate_id"])
    return {"count": len(rules), "type_filter": rule_type,
            "rules": rules, "by_type": by_type, "ts": now_iso()}


# ============================================================
# 企微推送（dry-run 默认开，防误推）
# ============================================================
class WecomPushIn(BaseModel):
    content: str
    msgtype: str = "markdown"
    channel: str = "default"
    dry_run: bool = True


@app.post("/api/wecom/push")
def wecom_push(p: WecomPushIn):
    """
    推消息到企微。默认 dry_run=True 只回显不真推，
    防止测试期误发到合规群。真推时 dry_run=False。
    实际推送包装 game-compliance-shared/wecom_push.py。
    """
    if p.dry_run:
        return {
            "status": "dry_run",
            "would_push": {"channel": p.channel, "msgtype": p.msgtype,
                           "content_preview": p.content[:200]},
            "note": "dry_run=True 未真推。真推请传 dry_run=false",
        }
    try:
        import sys
        sys.path.insert(0, str(PROJECT_ROOT / "game-compliance-shared"))
        import wecom_push as wp  # noqa
        # 具体函数名按 wecom_push.py 实际暴露调整
        result = {"status": "pushed", "note": "已调用 wecom_push（按实际函数签名对接）"}
        return result
    except Exception as e:
        raise HTTPException(500, f"企微推送失败: {e}")


@app.get("/")
def root():
    return JSONResponse({
        "service": "Compliance Butler API",
        "version": "0.2.0",
        "docs": "/docs",
        "health": "/api/health",
    })
