"""
GCC Butler MCP Server —— knot 智能体的 MCP 接入层（Streamable HTTP）

作用：把 butler_api 的 REST 接口包装成 MCP 工具，供 knot 智能体调用。
架构：knot --MCP--> 本服务(8902) --REST--> butler_api(8901) --> GitHub/本地数据

部署：灯塔机 systemd，绑 127.0.0.1:8902，Caddy 反代 mcp.<IP>.sslip.io
鉴权：自定义 header X-Butler-Token（knot 的 MCP 配置里 headers 携带）
"""
import os
import json
import urllib.request
import urllib.parse
import urllib.error
import ssl

from fastmcp import FastMCP
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

# ---------- 配置 ----------
BUTLER_BASE = os.environ.get("BUTLER_BASE", "http://127.0.0.1:8901")
MCP_TOKEN = os.environ.get("BUTLER_MCP_TOKEN", "")  # 空则不校验
MCP_PORT = int(os.environ.get("MCP_PORT", "8902"))
MCP_PATH = os.environ.get("MCP_PATH", "/mcp")

_ctx = ssl.create_default_context()


def _call(path, params=None):
    """同步调用 butler_api REST 接口，返回 dict。"""
    url = f"{BUTLER_BASE}{path}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "butler-mcp"})
        with urllib.request.urlopen(req, context=_ctx, timeout=30) as r:
            return json.loads(r.read().decode("utf-8", errors="ignore"))
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}", "detail": e.read().decode("utf-8", errors="ignore")[:200]}
    except Exception as e:
        return {"error": type(e).__name__, "detail": str(e)}


mcp = FastMCP("GCC 合规管家 Butler")


@mcp.tool
def daily_get(date: str) -> dict:
    """读取某一天的游戏合规日报全文。date 格式 YYYY-MM-DD，例如 2026-05-29。"""
    return _call("/api/daily/get", {"date": date})


@mcp.tool
def daily_status(date: str) -> dict:
    """查询某一天日报的产出状态：是否生成、P0/P1/P2 各级数量、候选池统计。date 格式 YYYY-MM-DD。"""
    return _call("/api/daily/status", {"date": date})


@mcp.tool
def archive_search(q: str, limit: int = 10, scope: str = "all", days: int = 30) -> dict:
    """
    在历史日报中全文检索关键词。
    q: 检索关键词（如 COPPA、抽卡、CFIUS）
    limit: 最多返回条数（默认 10）
    scope: all|daily|weekly（默认 all）
    days: 回溯最近 N 个日期（默认 30）
    用于合并查重：判断某事件是否近期已报过。
    """
    return _call("/api/archive/search", {"q": q, "limit": limit, "scope": scope, "days": days})


@mcp.tool
def sentinel_candidates(since: str = "24h") -> dict:
    """读取哨兵告警候选池（尚未整合进日报的告警条目）。since 如 24h / 48h。"""
    return _call("/api/sentinel/candidates", {"since": since})


@mcp.tool
def corrections_review(days: int = 7) -> dict:
    """查看最近 N 天的人工修正记录聚合（按 type 分类统计）。用于复盘学习。"""
    return _call("/api/corrections/review", {"days": days})


@mcp.tool
def health() -> dict:
    """健康检查 + 数据源自检（确认 GitHub 日报数据源、日期文件夹数量）。"""
    return _call("/api/health")


# ---------- 鉴权中间件 ----------
class TokenAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if MCP_TOKEN:
            token = request.headers.get("X-Butler-Token", "")
            if token != MCP_TOKEN:
                return JSONResponse({"error": "unauthorized"}, status_code=401)
        return await call_next(request)


# ASGI app（供 uvicorn 启动 + 加鉴权中间件）
app = mcp.http_app(path=MCP_PATH)
if MCP_TOKEN:
    app.add_middleware(TokenAuthMiddleware)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=MCP_PORT)
