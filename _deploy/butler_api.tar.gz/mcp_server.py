"""
GCC Butler MCP Server —— knot 智能体的 MCP 接入层（Streamable HTTP）

作用：把 butler_api 的 REST 接口包装成 MCP 工具，供 knot 智能体调用。
架构：knot --MCP--> 本服务(8902) --REST--> butler_api(8901) --> GitHub(日报public/周报private)/本地数据

部署：灯塔机 systemd，绑 127.0.0.1:8902，Caddy 反代 mcp.<IP>.sslip.io
鉴权：自定义 header X-Butler-Token（knot 的 MCP 配置里 headers 携带）
"""
import os
import json
import urllib.request
import urllib.parse
import urllib.error
import ssl

from fastmcp import FastMCP
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

# ---------- 配置 ----------
BUTLER_BASE = os.environ.get("BUTLER_BASE", "http://127.0.0.1:8901")
MCP_TOKEN = os.environ.get("BUTLER_MCP_TOKEN", "")  # 空则不校验
MCP_PORT = int(os.environ.get("MCP_PORT", "8902"))
MCP_PATH = os.environ.get("MCP_PATH", "/mcp")

_ctx = ssl.create_default_context()


def _call(path, params=None):
    """同步调用 butler_api REST 接口（GET），返回 dict。"""
    url = f"{BUTLER_BASE}{path}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "butler-mcp"})
        with urllib.request.urlopen(req, context=_ctx, timeout=30) as r:
            return json.loads(r.read().decode("utf-8", errors="ignore"))
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}", "detail": e.read().decode("utf-8", errors="ignore")[:200]}
    except Exception as e:
        return {"error": type(e).__name__, "detail": str(e)}


def _call_post(path, body):
    """同步调用 butler_api REST 接口（POST JSON），返回 dict。"""
    url = f"{BUTLER_BASE}{path}"
    try:
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url, data=data, method="POST",
            headers={"User-Agent": "butler-mcp", "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, context=_ctx, timeout=30) as r:
            return json.loads(r.read().decode("utf-8", errors="ignore"))
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}", "detail": e.read().decode("utf-8", errors="ignore")[:200]}
    except Exception as e:
        return {"error": type(e).__name__, "detail": str(e)}


mcp = FastMCP("GCC 合规管家 Butler")


@mcp.tool
def daily_get(date: str) -> dict:
    """读取某一天的游戏合规日报全文。date 格式 YYYY-MM-DD，例如 2026-05-29。"""
    return _call("/api/daily/get", {"date": date})


@mcp.tool
def weekly_list() -> dict:
    """列出所有可用的合规周报（每周导读），返回每期的周期串（如 2026.5.15-2026.5.21）与文件名，按时间降序。用于先查有哪些周报再决定读哪期。"""
    return _call("/api/weekly/list")


@mcp.tool
def weekly_get(period: str) -> dict:
    """读取某一期合规周报（每周导读）全文。period 为周期串，如 2026.5.15-2026.5.21（支持文件名子串模糊匹配）。先用 weekly_list 查可用周期。"""
    return _call("/api/weekly/get", {"period": period})


@mcp.tool
def daily_status(date: str) -> dict:
    """查询某一天日报的产出状态：是否生成、P0/P1/P2 各级数量、候选池统计。date 格式 YYYY-MM-DD。"""
    return _call("/api/daily/status", {"date": date})


@mcp.tool
def archive_search(q: str, limit: int = 10, scope: str = "all", days: int = 30) -> dict:
    """
    在历史日报中全文检索关键词。
    q: 检索关键词（如 COPPA、抽卡、CFIUS）
    limit: 最多返回条数（默认 10）
    scope: all|daily|weekly（默认 all）
    days: 回溯最近 N 个日期（默认 30）
    用于合并查重：判断某事件是否近期已报过。
    """
    return _call("/api/archive/search", {"q": q, "limit": limit, "scope": scope, "days": days})


@mcp.tool
def daily_qc_get(date: str = "") -> dict:
    """
    读取某天日报的【自动质检报告】。date 省略取最新。
    质检由每日定时流程产出，按 9 板块归属/P0必须Direct/合并查重/实质进展/信源等级
    等维度检查当天日报，返回 verdict(pass|warn|fail) + issues 问题清单 + stats 统计。
    用户问"今天日报质检结果""日报有什么问题"时调用。
    """
    params = {"date": date} if date else {}
    return _call("/api/daily/qc_get", params)


@mcp.tool
def daily_qc_list() -> dict:
    """列出所有已有日报质检报告的日期。"""
    return _call("/api/daily/qc_list")


@mcp.tool
def sentinel_candidates(since: str = "24h") -> dict:
    """读取哨兵告警候选池（尚未整合进日报的告警条目）。since 如 24h / 48h。"""
    return _call("/api/sentinel/candidates", {"since": since})


@mcp.tool
def sentinel_pending(date: str = "") -> dict:
    """
    读取哨兵【待侦察队列】（pending）——这是你（knot）要侦察校准的输入。
    date 省略则取最新一批。返回哨兵每 2 小时粗筛出的候选告警（仅关键词初判，未核实）。
    侦察流程：逐条读全文核实 → archive_search 查重 → 按 9 板块+P0必须Direct重新定级 →
    必要时 web 进一步搜证 → 用 sentinel_verify 写回真正有价值的条目。
    """
    params = {"date": date} if date else {}
    return _call("/api/sentinel/candidates", params)


@mcp.tool
def sentinel_verify(date: str, items: list, summary: str = "") -> dict:
    """
    把侦察校准后的【已核实告警】写回 verified 队列（只写真正有价值、需推送的条目）。
    date: YYYY-MM-DD（对应这批告警的日期）
    items: 已核实条目列表，每条建议含 title/url/p_level/tencent_tag/jurisdiction/topic/verdict/reason
    summary: 本批校准小结（如"5条粗筛→2条确认P1，3条降噪丢弃"）
    校准原则：P0 必须 tencent_tag=Direct 且已发生重大事件；传闻最高 P2；旧闻重炒/SEO 综述丢弃。
    """
    return _call_post("/api/sentinel/verify", {"date": date, "items": items, "summary": summary})


@mcp.tool
def alerts_verified(date: str = "") -> dict:
    """读取【已核实告警】（verified）——校准后确认要推送/留痕的告警。date 省略取最新。"""
    params = {"date": date} if date else {}
    return _call("/api/alerts/verified", params)


@mcp.tool
def corrections_review(days: int = 7) -> dict:
    """查看最近 N 天的人工修正记录聚合（按 type 分类统计）。用于复盘学习。"""
    return _call("/api/corrections/review", {"days": days})


@mcp.tool
def health() -> dict:
    """健康检查 + 数据源自检（确认 GitHub 日报数据源、日期文件夹数量）。"""
    return _call("/api/health")


# ---------- 鉴权中间件 ----------
# 只校验「初始化握手」请求（无 mcp-session-id 的 POST）。
# 后续请求（带 session-id）、会话清理（DELETE）、SSE 续传（GET）一律放行——
# 因为 session-id 本身就是握手成功后才发放的凭证，再拦会破坏 MCP 会话生命周期
# （knot 关闭会话发的 DELETE 不带 token，被拦会导致 client 报 timeout）。
class TokenAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if MCP_TOKEN:
            has_session = bool(request.headers.get("mcp-session-id"))
            # 仅对"无 session 的 POST"（即 initialize）强制校验 token
            if request.method == "POST" and not has_session:
                token = request.headers.get("X-Butler-Token", "")
                if token != MCP_TOKEN:
                    return JSONResponse({"error": "unauthorized"}, status_code=401)
        return await call_next(request)


# ASGI app（供 uvicorn 启动 + 加鉴权中间件）
app = mcp.http_app(path=MCP_PATH)
if MCP_TOKEN:
    app.add_middleware(TokenAuthMiddleware)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=MCP_PORT)
