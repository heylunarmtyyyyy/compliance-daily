"""
GCC Butler MCP Server —— knot 智能体的 MCP 接入层（Streamable HTTP）

作用：把 butler_api 的 REST 接口包装成 MCP 工具，供 knot 智能体调用。
架构：knot --MCP--> 本服务(8902) --REST--> butler_api(8901) --> GitHub(日报public/周报private)/本地数据

部署：灯塔机 systemd，绑 127.0.0.1:8902，Caddy 反代 mcp.<IP>.sslip.io
鉴权：自定义 header X-Butler-Token（knot 的 MCP 配置里 headers 携带）
"""
import os
import json
import urllib.request
import urllib.parse
import urllib.error
import ssl

from fastmcp import FastMCP
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

# ---------- 配置 ----------
BUTLER_BASE = os.environ.get("BUTLER_BASE", "http://127.0.0.1:8901")
MCP_TOKEN = os.environ.get("BUTLER_MCP_TOKEN", "")  # 空则不校验
MCP_PORT = int(os.environ.get("MCP_PORT", "8902"))
MCP_PATH = os.environ.get("MCP_PATH", "/mcp")

_ctx = ssl.create_default_context()


def _call(path, params=None):
    """同步调用 butler_api REST 接口（GET），返回 dict。"""
    url = f"{BUTLER_BASE}{path}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "butler-mcp"})
        with urllib.request.urlopen(req, context=_ctx, timeout=30) as r:
            return json.loads(r.read().decode("utf-8", errors="ignore"))
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}", "detail": e.read().decode("utf-8", errors="ignore")[:200]}
    except Exception as e:
        return {"error": type(e).__name__, "detail": str(e)}


def _call_post(path, body):
    """同步调用 butler_api REST 接口（POST JSON），返回 dict。"""
    url = f"{BUTLER_BASE}{path}"
    try:
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url, data=data, method="POST",
            headers={"User-Agent": "butler-mcp", "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, context=_ctx, timeout=30) as r:
            return json.loads(r.read().decode("utf-8", errors="ignore"))
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}", "detail": e.read().decode("utf-8", errors="ignore")[:200]}
    except Exception as e:
        return {"error": type(e).__name__, "detail": str(e)}


mcp = FastMCP("GCC 合规管家 Butler")


@mcp.tool
def daily_get(date: str) -> dict:
    """读取某一天的游戏合规日报全文。date 格式 YYYY-MM-DD，例如 2026-05-29。"""
    return _call("/api/daily/get", {"date": date})


@mcp.tool
def weekly_list() -> dict:
    """列出所有可用的合规周报（每周导读），返回每期的周期串（如 2026.5.15-2026.5.21）与文件名，按时间降序。用于先查有哪些周报再决定读哪期。"""
    return _call("/api/weekly/list")


@mcp.tool
def weekly_get(period: str) -> dict:
    """读取某一期合规周报（每周导读）全文。period 为周期串，如 2026.5.15-2026.5.21（支持文件名子串模糊匹配）。先用 weekly_list 查可用周期。"""
    return _call("/api/weekly/get", {"period": period})


@mcp.tool
def daily_status(date: str) -> dict:
    """查询某一天日报的产出状态：是否生成、P0/P1/P2 各级数量、候选池统计。date 格式 YYYY-MM-DD。"""
    return _call("/api/daily/status", {"date": date})


@mcp.tool
def archive_search(q: str, limit: int = 10, scope: str = "all", days: int = 30) -> dict:
    """
    在历史日报中全文检索关键词。
    q: 检索关键词（如 COPPA、抽卡、CFIUS）
    limit: 最多返回条数（默认 10）
    scope: all|daily|weekly（默认 all）
    days: 回溯最近 N 个日期（默认 30）
    用于合并查重：判断某事件是否近期已报过。
    """
    return _call("/api/archive/search", {"q": q, "limit": limit, "scope": scope, "days": days})


@mcp.tool
def daily_qc_get(date: str = "") -> dict:
    """
    读取某天日报的【自动质检报告】。date 省略取最新。
    质检由每日定时流程产出，按 9 板块归属/P0必须Direct/合并查重/实质进展/信源等级
    等维度检查当天日报，返回 verdict(pass|warn|fail) + issues 问题清单 + stats 统计。
    用户问"今天日报质检结果""日报有什么问题"时调用。
    """
    params = {"date": date} if date else {}
    return _call("/api/daily/qc_get", params)


@mcp.tool
def daily_qc_list() -> dict:
    """列出所有已有日报质检报告的日期。"""
    return _call("/api/daily/qc_list")


@mcp.tool
def propose_rule(proposed_rule: str, rule_type: str = "general", trigger_pattern: str = "",
                 evidence: str = "", expected_impact: str = "", risk: str = "") -> dict:
    """
    提议一条规则改进，写入规则候选区（待用户审批后生效）。
    当你和用户讨论中总结出"以后某类应该怎么判/怎么改"的经验时调用，把它沉淀下来。
    proposed_rule: 规则正文（如"印度真钱游戏查封不纳入日报"）
    rule_type: p_level|topic|juris|tencent_mark|source_grade|drop|merge|general
    trigger_pattern: 触发场景；evidence: 依据；expected_impact: 预期效果；risk: 风险
    护栏：只进候选区，不直接改生产规则。用户用 butler_cli rules approve 审批后才生效。
    """
    return _call_post("/api/corrections/propose_rule", {
        "proposed_rule": proposed_rule, "rule_type": rule_type,
        "trigger_pattern": trigger_pattern, "evidence": evidence,
        "expected_impact": expected_impact, "risk": risk})


@mcp.tool
def propose_keyword(keyword: str, action: str = "add", theme: str = "", reason: str = "") -> dict:
    """
    提议哨兵关键词调整，写入候选区（待审批）。当发现某板块/法域漏报、需要加监控关键词时调用。
    keyword: 关键词；action: add|modify|remove；theme: 所属板块；reason: 理由
    护栏：只提议，不直接改 sentinel-keywords.json。
    """
    return _call_post("/api/sentinel/propose_keyword", {
        "keyword": keyword, "action": action, "theme": theme, "reason": reason})


@mcp.tool
def corrections_pending(status: str = "pending_review") -> dict:
    """查看规则候选区（待用户审批的规则/关键词提议）。status=all 看全部。"""
    return _call("/api/corrections/pending", {"status": status})


@mcp.tool
def approve_rule(candidate_id: str, decision: str = "approve", reason: str = "") -> dict:
    """
    代用户审批一条规则候选（approve 批准 / reject 拒绝）。批准后规则落 learning/ 生效。

    🔴 严格护栏——只有当用户在对话中【明确表达审批意图】时才可调用本工具，例如：
      "我批准 rc-2026-W22-knot-001"、"通过那条规则"、"approve 这条"、"拒绝 kw-xxx"。
    禁止自主审批：你（knot）不得自己判断某候选该批就调用本工具。审批权属于用户，
    你只是代用户执行其口头批准——把"对你说的批准"翻译成一次 approve 调用。
    若用户只是讨论、提议或询问，绝不可调用本工具。

    用法：先用 corrections_pending 查待审批项拿到 candidate_id，复述给用户确认后再调用。
    candidate_id: 候选 id（如 rc-2026-W22-knot-001 / kw-...）
    decision: approve（批准，默认）| reject（拒绝）
    reason: 用户给出的理由（可选，原样转述）
    """
    return _call_post("/api/corrections/approve", {
        "candidate_id": candidate_id, "decision": decision,
        "reason": reason, "decided_by": "user"})


@mcp.tool
def active_rules(rule_type: str = "all") -> dict:
    """
    读取【已生效规则清单】——所有经用户审批通过的规则/关键词修正。

    🟢 何时调用：在你做任何合规判断前先调一次，把这些规则当作【最高优先级的增量规则】，
    叠加在知识库基线之上遵守。典型场景：
      - 给单条新闻判板块/P级/法域/纳入排除时
      - 做日报每日质检（daily_qc）时，按这些规则核查
      - 校准哨兵告警（sentinel_verify）时
    与知识库的区别：知识库是季度维护的基线；本清单是用户最近批准的最新修正，审批即生效。
    若清单里的规则与知识库基线冲突，以本清单为准（它更新、且经用户明确批准）。
    rule_type: all（默认）| drop | merge | topic | juris | p_level | keyword 等，按需筛选。
    """
    return _call("/api/rules/active", {"rule_type": rule_type})


@mcp.tool
def sentinel_candidates(since: str = "24h") -> dict:
    """读取哨兵告警候选池（尚未整合进日报的告警条目）。since 如 24h / 48h。"""
    return _call("/api/sentinel/candidates", {"since": since})


@mcp.tool
def sentinel_pending(date: str = "") -> dict:
    """
    读取哨兵【待侦察队列】（pending）——这是你（knot）要侦察校准的输入。
    date 省略则取最新一批。返回哨兵每 2 小时粗筛出的候选告警（仅关键词初判，未核实）。
    侦察流程：逐条读全文核实 → archive_search 查重 → 按 9 板块+P0必须Direct重新定级 →
    必要时 web 进一步搜证 → 用 sentinel_verify 写回真正有价值的条目。
    """
    params = {"date": date} if date else {}
    return _call("/api/sentinel/candidates", params)


@mcp.tool
def sentinel_verify(date: str, items: list, summary: str = "") -> dict:
    """
    把侦察校准后的【已核实告警】写回 verified 队列（只写真正有价值、需推送的条目）。
    date: YYYY-MM-DD（对应这批告警的日期）
    items: 已核实条目列表，每条建议含 title/url/p_level/tencent_tag/jurisdiction/topic/verdict/reason
    summary: 本批校准小结（如"5条粗筛→2条确认P1，3条降噪丢弃"）
    校准原则：P0 必须 tencent_tag=Direct 且已发生重大事件；传闻最高 P2；旧闻重炒/SEO 综述丢弃。
    """
    return _call_post("/api/sentinel/verify", {"date": date, "items": items, "summary": summary})


@mcp.tool
def alerts_verified(date: str = "") -> dict:
    """读取【已核实告警】（verified）——校准后确认要推送/留痕的告警。date 省略取最新。"""
    params = {"date": date} if date else {}
    return _call("/api/alerts/verified", params)


@mcp.tool
def corrections_review(days: int = 7) -> dict:
    """查看最近 N 天的人工修正记录聚合（按 type 分类统计）。用于复盘学习。"""
    return _call("/api/corrections/review", {"days": days})


@mcp.tool
def health() -> dict:
    """健康检查 + 数据源自检（确认 GitHub 日报数据源、日期文件夹数量）。"""
    return _call("/api/health")


# ---------- 鉴权中间件 ----------
# 只校验「初始化握手」请求（无 mcp-session-id 的 POST）。
# 后续请求（带 session-id）、会话清理（DELETE）、SSE 续传（GET）一律放行——
# 因为 session-id 本身就是握手成功后才发放的凭证，再拦会破坏 MCP 会话生命周期
# （knot 关闭会话发的 DELETE 不带 token，被拦会导致 client 报 timeout）。
class TokenAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if MCP_TOKEN:
            has_session = bool(request.headers.get("mcp-session-id"))
            # 仅对"无 session 的 POST"（即 initialize）强制校验 token
            if request.method == "POST" and not has_session:
                token = request.headers.get("X-Butler-Token", "")
                if token != MCP_TOKEN:
                    return JSONResponse({"error": "unauthorized"}, status_code=401)
        return await call_next(request)


# ASGI app（供 uvicorn 启动 + 加鉴权中间件）
app = mcp.http_app(path=MCP_PATH)
if MCP_TOKEN:
    app.add_middleware(TokenAuthMiddleware)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=MCP_PORT)
